# Yugi Oh Card Deck Informations

## Installation
    npm install

## Run app
    npm run start-dev