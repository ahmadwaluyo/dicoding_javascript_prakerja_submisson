import "regenerator-runtime";
import "bootstrap/dist/css/bootstrap.min.css";
import "./styles/main.css";
import "./scripts/search_bar";
import main from "./scripts/main";

main();